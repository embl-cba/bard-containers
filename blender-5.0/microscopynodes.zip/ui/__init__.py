from . import ops
from . import channel_list
from . import panel
from . import preferences

CLASSES = ops.CLASSES + channel_list.CLASSES + panel.CLASSES + preferences.CLASSES

